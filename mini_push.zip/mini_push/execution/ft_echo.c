#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "../includes/parser.h"


void ft_echo(t_token *tmp, bool n)
{
	int i = 0;

	while(i < tmp->location.lenght)
	{
		write(1, tmp->location.location + i, 1);
		i++;
	}
	if (!n && !tmp->up)
		write(1, "\n", 1);
    return ;
}

int pwd(char *cmd)
{
	int i = 0;
	while(cmd[i])
	{
		if(cmd[i] == '-')
		{
			printf("pwd: ");
			while(cmd[i] != '\0' && cmd[i] != '\n' && cmd[i] != '\t' && cmd[i] != ' ')
			{
				printf("%c", cmd[i]);
				i++;
			}
			printf(": invalid option\n");
			return 1;
		}
		i++;
	}
	printf("%s\n", getcwd(0, 0));
	return 0;
}
int cd_error(char *path);
int cd(char *path, char *home)
{

    if(path == NULL || (strlen(path) == 0) || path[0] == '~')
		chdir(home);
	else
	{
		int i = 0;
		while(path[i])
		{
			if(path[i] == ' ' && path[i + 1] != '\0')
			{
				return(write(1, "cd: too many arguments", 23), 1);
			}
			i++;
		}
		int n = chdir(path);
		if(n == -1)
			cd_error(path);
		
	}
	return 0;
}
int cd_error(char *path)
{
	int i;

	i = 0;
	write(1, "cd: ", 5);
	while(path[i])
	{
		write(1, &path[i], 1);
		i++;
	}
	write(1, ": ", 2);
	perror("");
	return 1;
}



int count_args(char **status)
{
    int i; 
    int j;
    int n;

    n = 0;
    i = 0;
    j = 1;
    
    while(status[j])
    {
        while(status[j][i])
        {
            i++;
        }
        i = 0;
        n++;
        j++;
    }
    return n;
}

int check_argtwo(char *status)
{
    int i = 0;
    while(status[i] > 47 && status[i] < 57)
        i++;
    if(i == strlen(status))
        return (0);
    return 1;
}

int ft_exit(char **status)
{
    int n = 0;
    int i = 0;
    if(count_args(status) == 0)
    {
        write(1, "exit\n", 5);
        exit(0);
    }
    else if(count_args(status) == 1)
    {
        if(check_argtwo(status[1]) == 1)
        {
            write(1, "minishell: ", 11);
            write(1, "exit: ", 6);
            while(status[1][i])
            {
                write(1, &status[1][i], 1);
                i++;
            }
            write(1, ": numeric argument required\n", 28);
            exit(2);
        }
        else {
            n = atoi(status[1]);
            write(1, "exit\n", 5);
            exit (n);
        }
    }
    else {
        if(check_argtwo(status[1]) == 1)
        {
            write(1, "minishell: ", 11);
            write(1, "exit: ", 6);
            while(status[1][i])
            {
                write(1, &status[1][i], 1);
                i++;
            }
            write(1, ": numeric argument required\n", 28);
            exit (2);
        }
        else {
            write(1, "minishell: exit: too many arguments\n", 36);
        }
    }
    return 0;
}

